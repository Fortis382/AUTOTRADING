import yaml, pandas as pd, numpy as np
from btcusdt_algo.core.indicators import add_indicators
from btcusdt_algo.core.features import build_features
from btcusdt_algo.core.scoring import SignalScorer, adaptive_threshold
from btcusdt_algo.core.mtf import resample_with_indicators, merge_mtf
from btcusdt_algo.core.session import score_mult, which as which_session
from btcusdt_algo.strategies.ensemble import route_by_regime
from btcusdt_algo.core.regime import classify_regime

# 엔진의 하드 게이트/폴백 불러오기
from btcusdt_algo.backtest.engine import _passes_entry_filters, _fallback_side

cfg = yaml.safe_load(open("config/settings.yaml","r",encoding="utf-8"))
df = pd.read_parquet("data/processed/BTCUSDT_1m.parquet")
df["timestamp"] = pd.to_datetime(df["timestamp"])

# 1) 인디케이터 + MTF + 피처
df = add_indicators(df, cfg)
d5  = resample_with_indicators(df, '5min', cfg, cols=('rsi','ema21'))
d15 = resample_with_indicators(df, '15min', cfg, cols=('rsi','ema21'))
df  = merge_mtf(df, d5, '5m')
df  = merge_mtf(df, d15, '15m')
df  = build_features(df, use_detectors=True, cfg=cfg)

# 2) 마이크로 트리거 1m
from btcusdt_algo.detectors.microtrigger import micro_triggers
micro = micro_triggers(
    df,
    lookback_break=int(cfg.get('micro',{}).get('break_lookback',10)),
    rsi_on=float(cfg.get('micro',{}).get('rsi_on',57.0))
)
df = pd.concat([df, micro], axis=1)

# 3) 레짐
reg = cfg.get('regime',{})
df['regime'] = classify_regime(
    df,
    reg.get('trend_adx_min',22),
    cfg['indicators'].get('bb_squeeze_th',0.028),
    reg.get('range_bb_width_max', None),
    reg.get('ema_slope_lookback', None),
    reg.get('ema_slope_min', None),
)

# 4) 점수 & 임계
weights = cfg.get('scoring_weights', {'volatility':0.25,'momentum':0.25,'volume':0.20,'structure':0.20,'fib':0.10})
sc = SignalScorer(weights=weights, squeeze_th=cfg['indicators'].get('bb_squeeze_th',0.028))
df['score_raw'] = df.apply(lambda r: sc.score_row(r, session_mult=1.0), axis=1)

thr = cfg.get('thresholding',{})
if thr.get('mode','fixed')=='adaptive':
    df['thr'] = adaptive_threshold(
        df['score_raw'],
        window_bars=int(thr.get('window_bars',4320)),
        pct=float(thr.get('adaptive_percentile',0.85)),
        floor=float(thr.get('floor',72))
    )
else:
    df['thr'] = float(thr.get('fixed_score_th',75.0))

# 5) 엔트리 가능성 체크 (엔진과 동일 로직)
f = cfg.get('filters', {})
sess_block = set(cfg.get('session',{}).get('block',[]) or [])
session_enabled = bool(cfg.get('session',{}).get('enable', False))  # 우리는 지금 False일 것

def would_enter(row) -> bool:
    # 필수 인디케이터
    if pd.isna(row['rsi']) or pd.isna(row['atr']) or pd.isna(row['bb_mid']) or pd.isna(row['bb_width']):
        return False

    # 세션 보정 점수 (enable=False면 1.0)
    sm = score_mult(cfg, row['timestamp'].to_pydatetime()) if session_enabled else 1.0
    if (row['score_raw'] * float(sm)) < float(row['thr']):
        return False

    # 세션 블록
    if sess_block and which_session(row['timestamp'].to_pydatetime()) in sess_block:
        return False

    # 방향
    strat = route_by_regime(row['regime'])
    side  = 'long' if strat.should_long(row) else ('short' if strat.should_short(row) else '')
    if not side:
        side = _fallback_side(row)
    if not side:
        return False

    # 마이크로: trend는 micro 신호, range는 끝단+RSI (engine 기본값과 동일)
    if str(row['regime']) == 'range':
        hi, lo = row.get('bb_high'), row.get('bb_low')
        if hi is None or lo is None or not (hi > lo):
            return False
        pos = (row['close'] - lo) / max(hi - lo, 1e-8)
        rsi = row.get('rsi', 50.0)
        e_lo = float(f.get('range_edge_low', 0.35))
        e_hi = float(f.get('range_edge_high', 0.65))
        r_long_max  = float(f.get('range_rsi_long_max', 48))
        r_short_min = float(f.get('range_rsi_short_min', 52))
        if side == 'long':
            micro_ok = (pos <= e_lo) and (rsi <= r_long_max)
        else:
            micro_ok = (pos >= e_hi) and (rsi >= r_short_min)
    else:
        micro_ok = (row.get('micro_long',False) if side=='long' else row.get('micro_short',False))
    if not micro_ok:
        return False

    # 하드 게이트 (MTF/MACD 등 레짐별 적용은 엔진 내부에서 처리)
    # return _passes_entry_filters(row, cfg, side)
    return True

# 6) 카운트
cand_mask = (~df[['rsi','atr','bb_mid','bb_width']].isna().any(axis=1)) & ((df['score_raw']>=df['thr']) if not session_enabled else ((df['score_raw']*df['timestamp'].apply(lambda t: score_mult(cfg, t.to_pydatetime())) )>=df['thr']))
cand = df[cand_mask]

with_side = []
for _, r in cand.iterrows():
    strat = route_by_regime(r['regime'])
    side  = 'long' if strat.should_long(r) else ('short' if strat.should_short(r) else '')
    if not side:
        side = _fallback_side(r)
    with_side.append(bool(side))
cand_with_side = int(np.sum(with_side))

mask = cand.apply(would_enter, axis=1).fillna(False).astype(bool)
enterable = int(mask.sum())

print("cand (score>=thr & indicators ok):", len(cand))
print("with side:", cand_with_side)
print("enterable (engine logic):", enterable)

# 샘플 5개만 출력
ex = cand[mask].head(5)[['timestamp','close','regime','score_raw','thr']]
print("\nexamples:")
print(ex.to_string(index=False))

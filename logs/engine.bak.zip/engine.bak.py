import pandas as pd
import numpy as np
import os, json
from loguru import logger
from datetime import datetime

from btcusdt_algo.core.indicators import add_indicators
from btcusdt_algo.core.regime import classify_regime
from btcusdt_algo.core.features import build_features
from btcusdt_algo.core.scoring import SignalScorer, adaptive_threshold
from btcusdt_algo.core.position import PositionManager
from btcusdt_algo.core.session import score_mult, which as which_session
from btcusdt_algo.core.mtf import resample_with_indicators, merge_mtf
from btcusdt_algo.detectors.microtrigger import micro_triggers
from btcusdt_algo.strategies.ensemble import route_by_regime
from btcusdt_algo.backtest.metrics import perf_headline, breakdowns

def _passes_entry_filters(row, settings, side: str) -> bool:
    """
    엔트리 하드 게이트:
    - 세션 차단 (settings.session.block)
    - MTF 정렬 (5m/15m RSI & EMA21 정렬)
    - MACD 히스토그램 부호 일치
    """
    f = settings.get('filters', {})
    ok = True

    # 1) 세션 차단
    sess_cfg = settings.get('session', {})
    blocked = set(sess_cfg.get('block', [])) if sess_cfg.get('block') else set()
    if blocked:
        # which_session은 이미 상단 import에 있음: which as which_session
        sess = which_session(row['timestamp'].to_pydatetime())
        if sess in blocked:
            return False

    # 2) MTF 정렬 (기본 On)
    if f.get('require_mtf', True):
        rsi_min = float(f.get('mtf_rsi_min', 52.0))  # 5m/15m 최소 RSI
        r5  = row.get('rsi_5m');  r15 = row.get('rsi_15m')
        e5  = row.get('ema21_5m'); e1 = row.get('ema21')
        # RSI 정렬
        if side == 'long':
            if r5 is not None and r5 < rsi_min: ok = False
            if r15 is not None and r15 < rsi_min: ok = False
        else:  # short
            if r5 is not None and r5 > 100 - rsi_min: ok = False
            if r15 is not None and r15 > 100 - rsi_min: ok = False
        if not ok: 
            return False
        # EMA 게이트(가격 vs 5m EMA, 없으면 1m EMA)
        if f.get('mtf_use_ema_gate', True):
            if side == 'long':
                if (e5 is not None and row['close'] < e5) and (e1 is not None and row['close'] < e1):
                    return False
            else:
                if (e5 is not None and row['close'] > e5) and (e1 is not None and row['close'] > e1):
                    return False

    # 3) MACD 히스토그램 부호 일치 (기본 On)
    if f.get('require_macd_hist_sign', True):
        mh = row.get('macd_hist', None)
        if mh is not None:
            if side == 'long' and mh < 0: return False
            if side == 'short' and mh > 0: return False

    return True

def run_backtest(data_path: str, settings: dict, score_override: float|None=None):
    settings.setdefault('filters', {
    'require_mtf': True,
    'mtf_rsi_min': 52.0,
    'mtf_use_ema_gate': True,
    'require_macd_hist_sign': True
})
    if not os.path.exists(data_path):
        logger.error(f"Data not found: {data_path}"); return {}
    df = pd.read_parquet(data_path)
    if df.empty:
        logger.error("Empty data"); return {}

    # 1) Indicators on 1m
    df = add_indicators(df, settings)

    # 2) MTF 5m & 15m context
    d5  = resample_with_indicators(df, '5T', settings, cols=('rsi','ema21'))
    d15 = resample_with_indicators(df, '15T', settings, cols=('rsi','ema21'))
    df = merge_mtf(df, d5,  '5m')
    df = merge_mtf(df, d15, '15m')

    # 3) Regime on 1m context
    reg = settings.get('regime', {})
    df['regime'] = classify_regime(df, reg.get('trend_adx_min',18), settings['indicators'].get('bb_squeeze_th',0.02))

    # 4) Detectors + features
    df = build_features(df, use_detectors=True, cfg=settings)

    # 5) Micro triggers (1m)
    micro = micro_triggers(df, lookback_break=int(settings.get('micro',{}).get('break_lookback',5)),
                              rsi_on=float(settings.get('micro',{}).get('rsi_on',52.0)))
    df = pd.concat([df, micro], axis=1)

    # 6) Scorer & PM
    w = settings.get('scoring_weights', {'volatility':0.25,'momentum':0.25,'volume':0.20,'structure':0.20,'fib':0.10})
    scorer = SignalScorer(weights=w, squeeze_th=settings['indicators'].get('bb_squeeze_th',0.02))
    rconf = settings.get('risk', {})
    tconf = settings.get('trailing', {})
    pm = PositionManager(rr=tuple(rconf.get('rr_base',[1,2])),
                         atr_sl_mult=float(rconf.get('atr_sl_mult_trend',1.2)),
                         trail_conf=tconf,
                         max_hold_minutes=int(rconf.get('max_hold_minutes',240)),
                         fees_bps_per_side=int(rconf.get('fees_bps_per_side',6)),
                         add_on_max=int(settings.get('position',{}).get('add_on_max',2)),
                         add_on_trigger_R=float(settings.get('position',{}).get('add_on_trigger_R',0.5)),
                         add_on_size_pct=float(settings.get('position',{}).get('add_on_size_pct',50)))

    # 7) Adaptive threshold series or fixed
    base_scores = df.apply(lambda r: scorer.score_row(r, session_mult=1.0), axis=1)
    df['score_raw'] = base_scores
    th_cfg = settings.get('thresholding', {})
    if score_override is not None:
        df['thr'] = score_override
    elif th_cfg.get('mode','fixed') == 'adaptive':
        df['thr'] = adaptive_threshold(df['score_raw'], window_bars=int(th_cfg.get('window_bars',4320)), pct=float(th_cfg.get('adaptive_percentile',0.7)), floor=float(th_cfg.get('floor',65.0)))
    else:
        df['thr'] = float(th_cfg.get('fixed_score_th',75.0))

    trades = []
    cooldown = int(settings.get('entries',{}).get('cooldown_bars',20))
    cool_left = 0

    for i, row in df.iterrows():
        if pd.isna(row['rsi']) or pd.isna(row['atr']) or pd.isna(row['bb_mid']) or pd.isna(row['bb_width']):
            continue
        now = row['timestamp'].to_pydatetime(); price = float(row['close']); rsi = float(row['rsi']); atr = float(row['atr'])

        # Maintain open position
        if not pm.flat():
            pm.update_trailing(price, rsi, atr)
            partials = pm.try_maintenance(price, now)
            for p in partials: trades.append(p)
            
            soft = pm.maybe_soft_tp(price, now, rsi, row.get('macd_hist', 0.0), settings.get('soft_tp', {}))
            if soft:
                trades.append(soft)
        # 포지션이 닫혔으니 이후 close 체크는 스킵
                continue
            
            closed = pm.try_close(price, now, rsi, atr)
            if closed: trades.append(closed)

        if cool_left > 0:
            cool_left -= 1
            continue

        # Entry
        if pm.flat():
            s_mult = score_mult(settings, now)
            score = scorer.score_row(row, session_mult=s_mult)
            thr = float(row['thr']) if not np.isnan(row['thr']) else 75.0
            if score >= thr:
                strat = route_by_regime(row['regime'])
                side = 'long' if strat.should_long(row) else ('short' if strat.should_short(row) else '')
                # 1m micro trigger gate
                ok_micro = (row.get('micro_long', False) if side=='long' else row.get('micro_short', False)) if side else False
                if side and ok_micro and _passes_entry_filters(row, settings, side):
                    # regime RR/SL
                    if row['regime'] == 'trend':
                        pm.rr = tuple(rconf.get('rr_trend', rconf.get('rr_base', [1, 2])))
                        pm.atr_sl_mult = float(rconf.get('atr_sl_mult_trend', 1.2))
                        pm.trail_conf['atr_trail_mult'] = float(tconf.get('atr_trail_mult_trend', 1.2))   # ← 추가
                    else:
                        pm.rr = tuple(rconf.get('rr_range', rconf.get('rr_base', [1, 2])))
                        pm.atr_sl_mult = float(rconf.get('atr_sl_mult_range', 1.0))
                        pm.trail_conf['atr_trail_mult'] = float(tconf.get('atr_trail_mult_range', 0.8))   # ← 추가
                    sess = which_session(now)
                    pm.open_position(side, price, atr, now, size=1.0, regime=row['regime'], strategy=type(strat).__name__, session=sess)
                    cool_left = cooldown

    # Close any remaining
    if not pm.flat():
        last = df.iloc[-1]
        now = last['timestamp'].to_pydatetime()
        closed = pm.try_close(float(last['close']), now, float(last['rsi']), float(last['atr']))
        if closed: trades.append(closed)

    # Reports
    headline = perf_headline(trades)
    by = breakdowns(trades)

    # Save artifacts
    os.makedirs('logs', exist_ok=True)
    ts = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    with open(f'logs/last_report_{ts}.json','w',encoding='utf-8') as f:
        json.dump({'headline':headline, 'breakdowns':by}, f, ensure_ascii=False, indent=2)
    if len(trades)>0:
        pd.DataFrame(trades).to_csv(f'logs/trades_{ts}.csv', index=False)

    report = dict(headline)
    report['details_saved'] = True
    return report

import yaml, pandas as pd
from btcusdt_algo.core.indicators import add_indicators
from btcusdt_algo.core.regime import classify_regime

cfg = yaml.safe_load(open("config/settings.yaml","r",encoding="utf-8"))
df = pd.read_parquet("data/processed/BTCUSDT_1m.parquet")
df = add_indicators(df, cfg)
reg = classify_regime(
    df,
    cfg["regime"]["trend_adx_min"],
    cfg["indicators"]["bb_squeeze_th"],
    cfg["regime"].get("range_bb_width_max")
)
print(reg.value_counts(normalize=True))

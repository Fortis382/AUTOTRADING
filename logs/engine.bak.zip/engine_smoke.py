import yaml
from btcusdt_algo.backtest.engine import run_backtest
s = yaml.safe_load(open('config/settings.yaml','r',encoding='utf-8'))
out = run_backtest('data/processed/BTCUSDT_1m.parquet', s)
print(out)

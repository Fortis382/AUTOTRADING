from dataclasses import dataclass, field
from typing import Optional, Dict, List
from datetime import datetime, timedelta

@dataclass
class Position:
    side: str = ""      # 'long' or 'short'
    entry: float = 0.0
    sl: float = 0.0
    tp: float = 0.0
    open: bool = False
    entry_time: Optional[datetime] = None
    last_update: Optional[datetime] = None
    rsi_trailing: bool = False
    size: float = 1.0
    init_risk: float = 0.0
    add_on_count: int = 0
    ladder: List[Dict] = field(default_factory=list)
    # tracking
    mfe_R: float = 0.0
    mae_R: float = 0.0
    regime: str = ""
    strategy: str = ""
    session: str = ""

class PositionManager:
    def __init__(self, rr=(1,2), atr_sl_mult=1.2, trail_conf=None, max_hold_minutes=240, fees_bps_per_side=6,
                 add_on_max:int=2, add_on_trigger_R:float=0.5, add_on_size_pct:float=50.0,
                 ladder_scheme:Optional[List[Dict]]=None):
        self.pos = Position()
        self.rr = rr
        self.atr_sl_mult = atr_sl_mult
        self.trail_conf = trail_conf or {"enable_rsi": True, "rsi_on_long": 65, "rsi_on_short": 35, "atr_trail_mult": 1.0}
        self.max_hold = timedelta(minutes=int(max_hold_minutes))
        self.fees_bps = fees_bps_per_side
        self.add_on_max = int(add_on_max)
        self.add_on_trigger_R = float(add_on_trigger_R)
        self.add_on_size_pct = float(add_on_size_pct) / 100.0
        self.default_ladder = ladder_scheme or [{"R":0.8, "pct":0.4, "done":False},
                                                {"R":1.5, "pct":0.3, "done":False},
                                                {"R":2.5, "pct":0.3, "done":False}]

    # ---- 소프트 TP (풀 익절 생성) ----
    def maybe_soft_tp(self, price: float, now, rsi: float, macd_hist: float, conf: dict):
        if not conf or not conf.get("enable", True) or not self.pos.open:
            return None

        r = self._current_R(price)
        # 1) 하드 캡: r_hard 이상이면 전량 익절
        if r >= float(conf.get("r_hard", 2.0)):
            R = self.settle_trade_R(price)
            side = self.pos.side; entry = self.pos.entry
            res = {"reason": "SOFT_TP_HARD", "R": round(R, 4), "side": side,
                   "exit": price, "entry": entry, "time": now,
                   "strategy": self.pos.strategy, "regime": self.pos.regime,
                   "session": self.pos.session, "mfe_R": self.pos.mfe_R,
                   "mae_R": self.pos.mae_R, "partial": False}
            self.pos = Position()
            return res

        # 2) 모멘텀 페이드: r_min 이상일 때만 검사
        if r >= float(conf.get("r_min", 1.2)):
            reason = None
            if conf.get("macd_flip", True):
                if (self.pos.side == "long" and macd_hist is not None and macd_hist < 0) or \
                   (self.pos.side == "short" and macd_hist is not None and macd_hist > 0):
                    reason = "SOFT_TP_MOM"
            if reason is None and rsi is not None:
                fade = float(conf.get("rsi_fade", 52.0))
                if (self.pos.side == "long" and rsi < fade) or (self.pos.side == "short" and rsi > (100 - fade)):
                    reason = "SOFT_TP_RSI"

            if reason:
                R = self.settle_trade_R(price)
                side = self.pos.side; entry = self.pos.entry
                res = {"reason": reason, "R": round(R, 4), "side": side,
                       "exit": price, "entry": entry, "time": now,
                       "strategy": self.pos.strategy, "regime": self.pos.regime,
                       "session": self.pos.session, "mfe_R": self.pos.mfe_R,
                       "mae_R": self.pos.mae_R, "partial": False}
                self.pos = Position()
                return res
        return None
    # ---------------------------------

    def flat(self) -> bool:
        return not self.pos.open

    def open_position(self, side: str, price: float, atr: float, now: datetime, size: float=1.0,
                      regime: str="", strategy: str="", session: str=""):
        sl_dist = max(atr * self.atr_sl_mult, 1e-8)
        tp_dist = sl_dist * (self.rr[1] / max(self.rr[0], 1e-8))
        if side == "long":
            sl = price - sl_dist; tp = price + tp_dist
        else:
            sl = price + sl_dist; tp = price - tp_dist
        self.pos = Position(side=side, entry=price, sl=sl, tp=tp, open=True, entry_time=now, last_update=now,
                            rsi_trailing=False, size=size, init_risk=sl_dist, add_on_count=0,
                            ladder=[dict(x) for x in self.default_ladder],
                            mfe_R=0.0, mae_R=0.0, regime=regime, strategy=strategy, session=session)

    def _current_R(self, price: float) -> float:
        if self.pos.init_risk <= 0: return 0.0
        if self.pos.side == "long":
            return (price - self.pos.entry) / self.pos.init_risk
        else:
            return (self.pos.entry - price) / self.pos.init_risk

    def update_excursions(self, price: float):
        r = self._current_R(price)
        if r > self.pos.mfe_R:
            self.pos.mfe_R = r
        if r < self.pos.mae_R:
            self.pos.mae_R = r

    def _apply_ladder(self, price: float, now: datetime) -> Optional[Dict]:
        curR = self._current_R(price)
        for lvl in self.pos.ladder:
            if not lvl.get("done") and curR >= float(lvl["R"]):
                lvl["done"] = True
                # 0.8R 이상 구간에서 BE(손익분기) 승격
                if lvl["R"] >= 0.8:
                    if self.pos.side == "long":
                        self.pos.sl = max(self.pos.sl, self.pos.entry)
                    else:
                        self.pos.sl = min(self.pos.sl, self.pos.entry)
                r_realized = curR - (2 * (self.fees_bps/10000.0))
                pct = float(lvl.get("pct", 0.0))
                return {"reason": f"TP{lvl['R']}R", "R": round(r_realized * pct, 4), "side": self.pos.side,
                        "exit": price, "entry": self.pos.entry, "time": now, "partial_pct": pct,
                        "strategy": self.pos.strategy, "regime": self.pos.regime, "session": self.pos.session,
                        "mfe_R": self.pos.mfe_R, "mae_R": self.pos.mae_R, "partial": True}
        return None

    def _maybe_add_on(self, price: float):
        if self.pos.add_on_count >= self.add_on_max: return
        curR = self._current_R(price)
        if curR >= self.add_on_trigger_R:
            add_size = self.pos.size * self.add_on_size_pct
            new_total = self.pos.size + add_size
            self.pos.entry = (self.pos.entry*self.pos.size + price*add_size) / new_total
            self.pos.size = new_total
            self.pos.add_on_count += 1

    def close_reason(self, price: float, now: datetime) -> Optional[str]:
        if not self.pos.open: return None
        if self.pos.side == "long":
            if price <= self.pos.sl: return "SL"
            if price >= self.pos.tp: return "TP"
        else:
            if price >= self.pos.sl: return "SL"
            if price <= self.pos.tp: return "TP"
        if now - (self.pos.entry_time or now) >= self.max_hold:
            return "TIME"
        return None

    def update_trailing(self, price: float, rsi: float, atr: float):
        if not self.pos.open or not self.trail_conf.get("enable_rsi", True):
            return

        # --- 트레일 시작 시점 제어 ---
        curR = self._current_R(price)
        start_R = float(self.trail_conf.get("trail_start_R", 0.8))        # 최소 이익 R
        wait_first = bool(self.trail_conf.get("wait_first_ladder", True)) # 라더 1회 후 허용
        ladder_done = any(l.get("done") for l in self.pos.ladder)

        if wait_first and not ladder_done:
            return
        if curR < start_R:
            return
        # -----------------------------

        # RSI로 트레일 활성화
        if self.pos.side == "long" and rsi >= float(self.trail_conf.get("rsi_on_long", 65)):
            self.pos.rsi_trailing = True
        if self.pos.side == "short" and rsi <= float(self.trail_conf.get("rsi_on_short", 35)):
            self.pos.rsi_trailing = True

        if self.pos.rsi_trailing:
            atr_trail = max(atr * float(self.trail_conf.get("atr_trail_mult", 1.0)), 1e-8)
            if self.pos.side == "long":
                self.pos.sl = max(self.pos.sl, price - atr_trail)
            else:
                self.pos.sl = min(self.pos.sl, price + atr_trail)

    def try_maintenance(self, price: float, now: datetime) -> list:
        events = []
        self.update_excursions(price)
        ev = self._apply_ladder(price, now)
        if ev: events.append(ev)
        self._maybe_add_on(price)
        return events

    def settle_trade_R(self, exit_price: float) -> float:
        if self.pos.init_risk <= 0: return 0.0
        r_mult = self._current_R(exit_price)
        fee_frac = 2 * (self.fees_bps / 10000.0)
        r_mult -= fee_frac
        return r_mult * self.pos.size

    def try_close(self, price: float, now: datetime, rsi: float, atr: float) -> Optional[Dict]:
        reason = self.close_reason(price, now)
        if reason:
            r = self.settle_trade_R(price)
            side = self.pos.side; entry = self.pos.entry
            res = {"reason": reason, "R": round(r, 4), "side": side, "exit": price, "entry": entry, "time": now,
                   "strategy": self.pos.strategy, "regime": self.pos.regime, "session": self.pos.session,
                   "mfe_R": self.pos.mfe_R, "mae_R": self.pos.mae_R, "partial": False}
            self.pos = Position()
            return res
        return None

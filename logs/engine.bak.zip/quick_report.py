# quick_report.py
import os, glob, json
import pandas as pd
import numpy as np

def _print_headline_from_json():
    jss = sorted(glob.glob(r'logs\last_report_*.json'))
    if not jss:
        print("recent last_report_*.json 없음.")
        return
    with open(jss[-1], "r", encoding="utf-8") as f:
        data = json.load(f)
    print("headline:", data.get("headline", {}))

def _print_debug_from_json():
    dbg_files = sorted(glob.glob(r'logs\last_debug_*.json'))
    if not dbg_files:
        print("recent last_debug_*.json 없음.")
        return
    with open(dbg_files[-1], "r", encoding="utf-8") as f:
        data = json.load(f)
    dbg = data.get("dbg", {})
    print("\n[debug] cand={cand} blocked_session={blocked_session} blocked_regime={blocked_regime} "
          "no_side={no_side} micro_fail={micro_fail} gate_fail={gate_fail} entered={entered}"
          .format(**{k: dbg.get(k, 0) for k in [
              "cand","blocked_session","blocked_regime","no_side","micro_fail","gate_fail","entered"
          ]}))
    sk = data.get("skipped_examples", [])[:5]
    if sk:
        print("[debug] skipped_examples(top5):")
        for s in sk:
            print(" - ts={ts} why={why} regime={regime} side={side} score_raw={score_raw} thr={thr}"
                  .format(ts=s.get("ts"),
                          why=s.get("why"),
                          regime=s.get("regime"),
                          side=s.get("side",""),
                          score_raw=s.get("score_raw",""),
                          thr=s.get("thr","")))

def _fmt(x, d=3):
    try:
        if np.isfinite(x):
            return f"{x:.{d}f}"
        return str(x)
    except Exception:
        return str(x)

def main():
    csvs = sorted(glob.glob(r'logs\trades_*.csv'))
    if not csvs:
        print("⚠️ trades_*.csv 없음 → 이번 백테스트 체결 0건 가능성 높음.")
        _print_headline_from_json()
        _print_debug_from_json()
        return

    p = csvs[-1]
    print("last trades file:", p)

    # 비어있는 CSV도 헤더만 있을 수 있음
    try:
        df = pd.read_csv(p)
    except Exception as e:
        print(f"CSV 읽기 실패: {e}")
        _print_headline_from_json()
        _print_debug_from_json()
        return

    if df.empty or ('R' not in df.columns) or df['R'].dropna().empty:
        print("csv는 있는데 비어 있음(체결 0).")
        _print_headline_from_json()
        _print_debug_from_json()
        return

    # 유효 R만 대상으로 분석
    d = df.copy()
    d = d[pd.to_numeric(d['R'], errors='coerce').notna()]
    d['R'] = d['R'].astype(float)

    n = len(d)
    wins = int((d['R'] > 0).sum())
    losses = int((d['R'] <= 0).sum())
    win_rate = 100.0 * wins / n if n else 0.0
    pos_sum = d.loc[d['R'] > 0, 'R'].sum()
    neg_sum = d.loc[d['R'] <= 0, 'R'].sum()
    pf = (pos_sum / abs(neg_sum)) if neg_sum < 0 else (float('inf') if neg_sum == 0 and pos_sum > 0 else 0.0)
    expectancy = d['R'].mean() if n else 0.0
    total_R = d['R'].sum()

    avg_win = d.loc[d['R'] > 0, 'R'].mean() if wins else 0.0
    avg_loss = d.loc[d['R'] <= 0, 'R'].mean() if losses else 0.0

    print(f"trades={n} wins={wins} losses={losses} win_rate%={_fmt(win_rate,2)} "
          f"avg_win_R={_fmt(avg_win)} avg_loss_R={_fmt(avg_loss)} "
          f"expectancy_R={_fmt(expectancy)} PF≈{_fmt(pf)} total_R={_fmt(total_R)}")

    # Top reasons
    if 'reason' in d.columns:
        print("\nTop reasons:")
        print(d['reason'].value_counts().head(10))
    else:
        print("\n'reason' 컬럼이 없어 이유 집계는 생략.")

    # 보조 요약(선택): 레짐/사이드
    extra = []
    if 'regime' in d.columns:
        reg_ct = d['regime'].value_counts().to_dict()
        extra.append(f"regime dist: {reg_ct}")
    if 'side' in d.columns:
        side_ct = d['side'].value_counts().to_dict()
        extra.append(f"side dist: {side_ct}")
    if extra:
        print("\n" + " | ".join(extra))

    # 디버그 json도 함께 출력(최근 것)
    _print_debug_from_json()

if __name__ == "__main__":
    main()

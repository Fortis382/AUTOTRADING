# PATCH3 Notes
Add to your `config/settings.yaml` (or ensure these exist):

micro:
  break_lookback: 5
  rsi_on: 52.0

thresholding:
  mode: adaptive
  adaptive_percentile: 0.7
  window_bars: 4320
  floor: 65

session:
  enable: true
  asia:   {score_mult: 1.05}
  europe: {score_mult: 1.00}
  us:     {score_mult: 0.95}

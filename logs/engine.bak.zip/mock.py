import json,glob,os
p=max(glob.glob(r'logs\last_debug_*.json'), key=os.path.getmtime)
d=json.load(open(p,encoding='utf-8'))
print("DBG:", d["dbg"])
print("REASONS:", d["dists"]["reason"])

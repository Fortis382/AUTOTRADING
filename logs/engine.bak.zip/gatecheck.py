import yaml, pandas as pd, numpy as np
from btcusdt_algo.core.indicators import add_indicators
from btcusdt_algo.core.features import build_features
from btcusdt_algo.core.scoring import SignalScorer, adaptive_threshold
from btcusdt_algo.core.mtf import resample_with_indicators, merge_mtf
from btcusdt_algo.core.session import which as which_session
from btcusdt_algo.strategies.ensemble import route_by_regime
from btcusdt_algo.core.regime import classify_regime

# 엔진의 폴백 방향 함수 가져오기 (없으면 로컬 정의)
try:
    from btcusdt_algo.backtest.engine import _fallback_side
except Exception:
    def _fallback_side(row) -> str:
        rsi = row.get('rsi', np.nan)
        ema = row.get('ema21', np.nan)
        mh  = row.get('macd_hist', np.nan)
        close = row.get('close', np.nan)
        # trend: MACD 또는 가격 vs EMA로 방향
        if row.get('regime') == 'trend':
            if pd.notna(mh) and mh > 0: return 'long'
            if pd.notna(mh) and mh < 0: return 'short'
            if pd.notna(ema) and pd.notna(close):
                return 'long' if close >= ema else 'short'
        # range: 밴드 끝단 위치로 mean-revert
        hi = row.get('bb_high', np.nan); lo = row.get('bb_low', np.nan)
        if pd.notna(hi) and pd.notna(lo) and hi > lo and pd.notna(close):
            pos = (close - lo) / max(hi - lo, 1e-8)
            if pos <= 0.25: return 'long'
            if pos >= 0.75: return 'short'
        return ''

cfg = yaml.safe_load(open("config/settings.yaml","r",encoding="utf-8"))
df = pd.read_parquet("data/processed/BTCUSDT_1m.parquet")
df["timestamp"] = pd.to_datetime(df["timestamp"])

# 인디케이터 + MTF + 피처
df = add_indicators(df, cfg)
d5  = resample_with_indicators(df, '5min', cfg, cols=('rsi','ema21'))
d15 = resample_with_indicators(df, '15min', cfg, cols=('rsi','ema21'))
df  = merge_mtf(df, d5, '5m')
df  = merge_mtf(df, d15, '15m')
df  = build_features(df, use_detectors=True, cfg=cfg)

# 1m 마이크로 트리거
from btcusdt_algo.detectors.microtrigger import micro_triggers
micro = micro_triggers(df,
    lookback_break=int(cfg.get('micro',{}).get('break_lookback',10)),
    rsi_on=float(cfg.get('micro',{}).get('rsi_on',57.0))
)
df = pd.concat([df, micro], axis=1)

# 레짐
reg = cfg.get('regime',{})
df['regime'] = classify_regime(
    df,
    reg.get('trend_adx_min',22),
    cfg['indicators'].get('bb_squeeze_th',0.028),
    reg.get('range_bb_width_max', None),
    reg.get('ema_slope_lookback', None),
    reg.get('ema_slope_min', None),
)

# 점수 & 임계
weights = cfg.get('scoring_weights', {'volatility':0.25,'momentum':0.25,'volume':0.20,'structure':0.20,'fib':0.10})
sc = SignalScorer(weights=weights, squeeze_th=cfg['indicators'].get('bb_squeeze_th',0.028))
df['score_raw'] = df.apply(lambda r: sc.score_row(r, session_mult=1.0), axis=1)

thr = cfg.get('thresholding',{})
if thr.get('mode','fixed')=='adaptive':
    df['thr'] = adaptive_threshold(
        df['score_raw'],
        window_bars=int(thr.get('window_bars',4320)),
        pct=float(thr.get('adaptive_percentile',0.85)),
        floor=float(thr.get('floor',72))
    )
else:
    df['thr'] = float(thr.get('fixed_score_th',75.0))

cand = df[(~df[['rsi','atr','bb_mid','bb_width']].isna().any(axis=1)) & (df['score_raw']>=df['thr'])].copy()

# 이유별 카운트
reasons = {
    'no_side':0,'micro_fail':0,'session_block':0,'mtf_rsi_fail':0,
    'ema_gate_fail':0,'macd_sign_fail':0,'pass_all':0
}
f = cfg.get('filters', {})
sess_block = set(cfg.get('session',{}).get('block',[]) or [])
rsi_min = float(f.get('mtf_rsi_min',52.0))
use_mtf = bool(f.get('require_mtf', True))
use_ema_gate = bool(f.get('mtf_use_ema_gate', True))
use_macd_sign = bool(f.get('require_macd_hist_sign', True))
mtf_mode = str(f.get('mtf_rsi_mode','and')).lower()
apply_in = {str(x).lower() for x in f.get('mtf_apply_in', ['trend'])}  # 기본 trend만
macd_apply_in = {str(x).lower() for x in f.get('macd_apply_in', ['trend'])}

for _, row in cand.iterrows():
    # 1) 전략 방향 (+ 폴백)
    strat = route_by_regime(row['regime'])
    side  = 'long' if strat.should_long(row) else ('short' if strat.should_short(row) else '')
    if not side:
        side = _fallback_side(row)
    if not side:
        reasons['no_side'] += 1
        continue

    # 2) 마이크로: range는 '끝단+RSI', trend는 micro 시그널
    if row['regime'] == 'range':
        hi, lo = row.get('bb_high'), row.get('bb_low')
        micro_ok = False
        if hi is not None and lo is not None and hi > lo:
            pos = (row['close'] - lo) / max(hi - lo, 1e-8)
            rsi = row.get('rsi', 50.0)
            e_lo = float(f.get('range_edge_low', 0.30))
            e_hi = float(f.get('range_edge_high', 0.70))
            r_long_max  = float(f.get('range_rsi_long_max', 46))
            r_short_min = float(f.get('range_rsi_short_min', 54))
            if side == 'long':
                micro_ok = (pos <= e_lo) and (rsi <= r_long_max)
            else:
                micro_ok = (pos >= e_hi) and (rsi >= r_short_min)
    else:
        micro_ok = (row.get('micro_long',False) if side=='long' else row.get('micro_short',False))

    # ★ 누락됐던 부분: 마이크로 실패 처리
    if not micro_ok:
        reasons['micro_fail'] += 1
        continue

    # 3) 세션 블록
    if sess_block and which_session(row['timestamp'].to_pydatetime()) in sess_block:
        reasons['session_block'] += 1
        continue

    # 4) MTF (적용 레짐 한정)
    if use_mtf and str(row.get('regime','')).lower() in apply_in:
        r5, r15 = row.get('rsi_5m'), row.get('rsi_15m')
        # RSI 게이트
        if mtf_mode == 'and':
            if side=='long':
                if (r5 is not None and r5 < rsi_min) or (r15 is not None and r15 < rsi_min):
                    reasons['mtf_rsi_fail'] += 1; continue
            else:
                if (r5 is not None and r5 > 100-rsi_min) or (r15 is not None and r15 > 100-rsi_min):
                    reasons['mtf_rsi_fail'] += 1; continue
        else:  # 'or'
            flags = []
            if r5 is not None:  flags.append(r5 >= rsi_min if side=='long' else r5 <= 100-rsi_min)
            if r15 is not None: flags.append(r15 >= rsi_min if side=='long' else r15 <= 100-rsi_min)
            if flags and not any(flags):
                reasons['mtf_rsi_fail'] += 1; continue

        # EMA 게이트 (5m·1m 둘 다 역행일 때만 컷)
        if use_ema_gate:
            e5, e1 = row.get('ema21_5m'), row.get('ema21')
            if side=='long' and (e5 is not None and row['close']<e5) and (e1 is not None and row['close']<e1):
                reasons['ema_gate_fail'] += 1; continue
            if side=='short' and (e5 is not None and row['close']>e5) and (e1 is not None and row['close']>e1):
                reasons['ema_gate_fail'] += 1; continue

    # 5) MACD 부호 (레짐 한정)
    if use_macd_sign and str(row.get('regime','')).lower() in macd_apply_in:
        mh = row.get('macd_hist', None)
        if mh is not None:
            dead = float(f.get('macd_deadband', 0.0))
            if abs(mh) > dead:
                if (side=='long' and mh < 0) or (side=='short' and mh > 0):
                    reasons['macd_sign_fail'] += 1
                    continue

    # ★ 누락됐던 부분: 모든 필터 통과 시 카운트
    reasons['pass_all'] += 1

print("score>=thr bars:", len(cand))
for k,v in reasons.items():
    print(f"{k}: {v}")
print("sum =", sum(reasons.values()))

# check_engine3.py
import inspect
import btcusdt_algo.backtest.engine as eng
print("ENGINE_FILE:", eng.__file__)
src = inspect.getsource(eng.run_backtest)
print("HAS_HARDENED_TOKEN:", "[HARDENED_SAVE_BLOCK]" in src)
print("FORCE_TO_CSV:", ".to_csv(csv_path" in src and "df_trades =" in src)
print("HAS_IF_LEN_TRADES_GUARD:", "if len(trades) > 0" in src)

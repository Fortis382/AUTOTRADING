# check_engine.py
import inspect
import btcusdt_algo.backtest.engine as eng

print("ENGINE_FILE:", eng.__file__)

src = inspect.getsource(eng.run_backtest)

# 핵심 토큰들 존재 여부
print("HAS_FALLBACK_SIDE:", "_fallback_side(" in src)
print("USE_SESSION_FLAG:", "use_session_mult_for_score" in src or "compare_mode" in src)

# 저장 블록(항상 CSV/JSON 생성) 힌트 토큰들
has_save_block = all(tok in src for tok in [
    "os.makedirs('logs'",          # logs 디렉토리 보장
    "strftime('%Y%m%d_%H%M%S')",   # 타임스탬프 파일명
    "last_report_",                # JSON 리포트 저장
    "trades_",                     # 트레이드 CSV 저장
    "to_csv(",                     # CSV 저장 호출
])
print("HAS_SAVE_BLOCK:", has_save_block)

# 디버그 JSON(선택) 생성 여부
print("HAS_DEBUG_JSON:", "last_debug_" in src)

# 확인용: to_csv 호출 근처 스니펫
idx = src.find("to_csv(")
print("TO_CSV_SNIPPET:", src[max(0, idx-60): idx+120] if idx != -1 else "not found")

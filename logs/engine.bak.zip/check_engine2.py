import inspect, os, sys
import btcusdt_algo.backtest.engine as eng

src = inspect.getsource(eng.run_backtest)
print("ENGINE_FILE:", eng.__file__)
print("HAS_HARDENED_TOKEN:", "[engine] trades CSV written:" in src)  # 내가 넣은 로그 토큰
print("RUNBT_LOC:", eng.run_backtest.__code__.co_filename, eng.run_backtest.__code__.co_firstlineno)

# 현재 작업 디렉토리도 출력 (상대경로 저장 문제 확인)
print("CWD:", os.getcwd())

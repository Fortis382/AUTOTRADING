import os
import yaml
import pandas as pd
import numpy as np
from btcusdt_algo.core.indicators import add_indicators

CFG_PATH = "config/settings.yaml"
DATA_PATH = "data/processed/BTCUSDT_1m.parquet"  # 필요 시 여기 경로 수정

# 1) 설정 로드
cfg = yaml.safe_load(open(CFG_PATH, "r", encoding="utf-8"))

# 2) 데이터 로드
if not os.path.exists(DATA_PATH):
    raise FileNotFoundError(f"Data not found: {DATA_PATH}")
df = pd.read_parquet(DATA_PATH)
if "timestamp" in df.columns:
    df["timestamp"] = pd.to_datetime(df["timestamp"])

# 3) 인디케이터 계산 (bb_width 생성)
df = add_indicators(df, cfg)

if "bb_width" not in df.columns:
    print("bb_width 칼럼이 없습니다. 사용 가능한 칼럼 목록:")
    print(df.columns.tolist())
    raise SystemExit(1)

# 4) 분포 확인 + 추천 구간
s = df["bb_width"].dropna()
desc = s.describe(percentiles=[0.10, 0.20, 0.25, 0.30, 0.35, 0.50, 0.75, 0.90])
print(desc)

q25 = s.quantile(0.25)
q35 = s.quantile(0.35)
print(f"\n추천 초기값: regime.range_bb_width_max ≈ {q25:.6f} ~ {q35:.6f}")

# 현재 YAML 값이 있으면, 그 값으로 '좁은 구간' 비중도 보여주기
rbw = cfg.get("regime", {}).get("range_bb_width_max", None)
if rbw is not None:
    rbw = float(rbw)
    prop = (s <= rbw).mean()
    print(f"현재 설정({rbw})이면 BB폭 기준으로 약 {prop:.2%}가 레인지 후보입니다.")

import os, json
from datetime import datetime
import pandas as pd
import numpy as np
from loguru import logger

from btcusdt_algo.core.indicators import add_indicators
from btcusdt_algo.core.regime import classify_regime
from btcusdt_algo.core.features import build_features
from btcusdt_algo.core.scoring import SignalScorer, adaptive_threshold
from btcusdt_algo.core.position import PositionManager
from btcusdt_algo.core.session import score_mult, which as which_session
from btcusdt_algo.core.mtf import resample_with_indicators, merge_mtf
from btcusdt_algo.detectors.microtrigger import micro_triggers
from btcusdt_algo.strategies.ensemble import route_by_regime
from btcusdt_algo.backtest.metrics import perf_headline, breakdowns

# -------------------------------------------------
# 폴백 방향 (gatecheck/quick_probe와 같은 규칙)
# -------------------------------------------------
def _fallback_side(row) -> str:
    rsi = row.get('rsi', np.nan)
    ema = row.get('ema21', np.nan)
    mh  = row.get('macd_hist', np.nan)
    close = row.get('close', np.nan)

    # trend: MACD > 0 롱 / < 0 숏, 없으면 가격 vs EMA
    if row.get('regime') == 'trend':
        if pd.notna(mh) and mh > 0: return 'long'
        if pd.notna(mh) and mh < 0: return 'short'
        if pd.notna(ema) and pd.notna(close):
            return 'long' if close >= ema else 'short'

    # range: 밴드 끝단 기준
    hi = row.get('bb_high', np.nan); lo = row.get('bb_low', np.nan)
    if pd.notna(hi) and pd.notna(lo) and hi > lo and pd.notna(close):
        pos = (close - lo) / max(hi - lo, 1e-8)  # 0=하단, 1=상단
        if pos <= 0.25: return 'long'
        if pos >= 0.75: return 'short'
    return ''

# -------------------------------------------------
# 엔트리 하드 게이트 (gatecheck와 완전 동일)
# -------------------------------------------------
def _passes_entry_filters(row, settings, side: str) -> bool:
    f = settings.get('filters', {})

    # 0) 세션 차단
    sess_cfg = settings.get('session', {})
    blocked = set(sess_cfg.get('block', []) or [])
    if blocked:
        sess = which_session(row['timestamp'].to_pydatetime())
        if sess in blocked:
            return False

    regime = str(row.get('regime','')).lower()

    # 레짐 화이트리스트
    allow = {str(x).lower() for x in (f.get('trade_in_regimes', []) or [])}
    if allow and regime not in allow:
        return False

    # 1) MTF (특정 레짐에만 적용)
    if f.get('require_mtf', True):
        apply_in = {str(x).lower() for x in f.get('mtf_apply_in', ['trend'])}
        if regime in apply_in:
            rsi_min = float(f.get('mtf_rsi_min', 52.0))
            mode    = str(f.get('mtf_rsi_mode', 'and')).lower()  # 'and' | 'or'
            r5, r15 = row.get('rsi_5m'), row.get('rsi_15m')
            e5, e1  = row.get('ema21_5m'), row.get('ema21')
            close   = row.get('close')

            # RSI 게이트
            if mode == 'and':
                if side == 'long':
                    if (r5 is not None and r5 < rsi_min) or (r15 is not None and r15 < rsi_min):
                        return False
                else:
                    if (r5 is not None and r5 > 100 - rsi_min) or (r15 is not None and r15 > 100 - rsi_min):
                        return False
            else:  # 'or'
                flags = []
                if r5 is not None:
                    flags.append(r5 >= rsi_min if side=='long' else r5 <= 100 - rsi_min)
                if r15 is not None:
                    flags.append(r15 >= rsi_min if side=='long' else r15 <= 100 - rsi_min)
                if flags and not any(flags):
                    return False

            # EMA 게이트 (5m/1m 둘 다 역행일 때만 컷)
            if f.get('mtf_use_ema_gate', True):
                if side == 'long':
                    if (e5 is not None and close < e5) and (e1 is not None and close < e1):
                        return False
                else:
                    if (e5 is not None and close > e5) and (e1 is not None and close > e1):
                        return False

    # 2) MACD 히스토그램 부호 (특정 레짐에만 적용)
    if f.get('require_macd_hist_sign', True):
        macd_apply_in = {str(x).lower() for x in f.get('macd_apply_in', ['trend'])}
        if regime in macd_apply_in:
            mh = row.get('macd_hist', None)
            if mh is not None:
                dead = float(f.get('macd_deadband', 0.0))
                if abs(mh) > dead:
                    if side == 'long' and mh < 0: return False
                    if side == 'short' and mh > 0: return False

    # 3) range 볼가드
    if regime == 'range':
        bbw = row.get('bb_width', None)
        if bbw is not None:
            bbw_min = float(f.get('range_bbw_min', 0.0010))
            bbw_max = float(f.get('range_bbw_max', 0.0040))
            if bbw < bbw_min or bbw > bbw_max:
                return False
        # ATR 퍼센트 상한
        close = float(row.get('close', 0.0)) or 1.0
        atrp  = float(row.get('atr', 0.0)) / close
        if atrp > float(f.get('range_atr_pct_max', 0.0040)):
            return False

    return True

# -------------------------------------------------
# 메인 백테스트
# -------------------------------------------------
def run_backtest(data_path: str, settings: dict, score_override: float|None=None):
    # 기본 필터 디폴트
    settings.setdefault('filters', {
        'require_mtf': True,
        'mtf_rsi_min': 52.0,
        'mtf_use_ema_gate': True,
        'require_macd_hist_sign': True
    })

    if not os.path.exists(data_path):
        logger.error(f"Data not found: {data_path}")
        return {}
    df = pd.read_parquet(data_path)
    if df.empty:
        logger.error("Empty data")
        return {}

    # 1) 인디케이터(1m)
    df = add_indicators(df, settings)

    # 2) MTF 5m & 15m (pandas 경고 없는 '5min','15min' 사용)
    d5  = resample_with_indicators(df, '5min',  settings, cols=('rsi','ema21'))
    d15 = resample_with_indicators(df, '15min', settings, cols=('rsi','ema21'))
    df = merge_mtf(df, d5,  '5m')
    df = merge_mtf(df, d15, '15m')

    # 3) 레짐
    reg = settings.get('regime', {})
    df['regime'] = classify_regime(
        df,
        reg.get('trend_adx_min', 18),
        settings['indicators'].get('bb_squeeze_th', 0.02),
        reg.get('range_bb_width_max', None),
        reg.get('ema_slope_lookback', 5),
        reg.get('ema_slope_min', 0.0006)
    )

    # 4) 디텍터 + 피처
    df = build_features(df, use_detectors=True, cfg=settings)

    # 5) 1m 마이크로 트리거
    micro = micro_triggers(
        df,
        lookback_break=int(settings.get('micro',{}).get('break_lookback', 5)),
        rsi_on=float(settings.get('micro',{}).get('rsi_on', 52.0))
    )
    df = pd.concat([df, micro], axis=1)

    # 6) 스코어러 & 포지션 매니저
    w = settings.get('scoring_weights', {'volatility':0.25,'momentum':0.25,'volume':0.20,'structure':0.20,'fib':0.10})
    scorer = SignalScorer(weights=w, squeeze_th=settings['indicators'].get('bb_squeeze_th', 0.02))
    rconf = settings.get('risk', {})
    tconf = settings.get('trailing', {})
    pconf = settings.get('position', {})

    pm = PositionManager(
        rr=tuple(rconf.get('rr_base', [1,2])),
        atr_sl_mult=float(rconf.get('atr_sl_mult_trend', 1.2)),   # 진입 시 레짐별로 재세팅
        trail_conf=tconf,
        max_hold_minutes=int(rconf.get('max_hold_minutes', 240)),
        fees_bps_per_side=int(rconf.get('fees_bps_per_side', 6)),
        add_on_max=int(pconf.get('add_on_max', 0)),
        add_on_trigger_R=float(pconf.get('add_on_trigger_R', 0.8)),
        add_on_size_pct=float(pconf.get('add_on_size_pct', 33)),
        ladder_scheme=pconf.get('ladder', None),
        be_at_R=float(pconf.get('be_at_R', 0.8)),
    )

    # 7) 임계값(어댑티브/고정)
    df['score_raw'] = df.apply(lambda r: scorer.score_row(r, session_mult=1.0), axis=1)
    th_cfg = settings.get('thresholding', {})
    if score_override is not None:
        df['thr'] = float(score_override)
    elif th_cfg.get('mode','fixed') == 'adaptive':
        df['thr'] = adaptive_threshold(
            df['score_raw'],
            window_bars=int(th_cfg.get('window_bars', 4320)),
            pct=float(th_cfg.get('adaptive_percentile', 0.7)),
            floor=float(th_cfg.get('floor', 65.0))
        )
    else:
        df['thr'] = float(th_cfg.get('fixed_score_th', 75.0))

    trades = []
    cooldown = int(settings.get('entries',{}).get('cooldown_bars', 20))
    cool_left = 0

    # ★ 세션 점수 멀티플라이어 사용 토글 (지금은 꺼둠 → gatecheck와 정합)
    use_session_mult_for_score = False  # 나중에 True로 켜고, gatecheck/quick_probe도 동일 수식으로 맞추자.

    for _, row in df.iterrows():
        # 필수 인디케이터 없으면 스킵
        if pd.isna(row['rsi']) or pd.isna(row['atr']) or pd.isna(row['bb_mid']) or pd.isna(row['bb_width']):
            continue

        now   = row['timestamp'].to_pydatetime()
        price = float(row['close'])
        rsi   = float(row['rsi'])
        atr   = float(row['atr'])

        # 1) 오픈 포지션 유지/정산
        if not pm.flat():
            pm.update_trailing(price, rsi, atr)
            partials = pm.try_maintenance(price, now)
            for p in partials:
                trades.append(p)

            # 소프트 TP (전량 청산 포함) → 전량이면 다음 캔들
            soft = pm.maybe_soft_tp(price, now, rsi, row.get('macd_hist', 0.0), settings.get('soft_tp', {}))
            if soft:
                trades.append(soft)
                if pm.flat():
                    continue

            closed = pm.try_close(price, now, rsi, atr)
            if closed:
                trades.append(closed)
                continue

        # 2) 쿨다운
        if cool_left > 0:
            cool_left -= 1
            continue

        # 3) 진입 로직
        if pm.flat():
            # 점수 비교: gatecheck/quick_probe와 동일하게 (raw vs thr)
            score_raw = float(row.get('score_raw', 0.0))
            thr = float(row.get('thr', 75.0))
            if use_session_mult_for_score:
                try:
                    s_mult = score_mult(settings, now)
                except Exception:
                    s_mult = 1.0
                score_eff = score_raw * float(s_mult)
            else:
                score_eff = score_raw

            if score_eff >= thr:
                strat = route_by_regime(row['regime'])
                side  = 'long' if strat.should_long(row) else ('short' if strat.should_short(row) else '')
                if not side:
                    side = _fallback_side(row)

                if side:
                    # 마이크로 트리거: trend=1m micro, range=끝단+RSI
                    reg = str(row.get('regime','')).lower()
                    if reg == 'range':
                        hi, lo = row.get('bb_high'), row.get('bb_low')
                        ok_micro = False
                        if pd.notna(hi) and pd.notna(lo) and hi > lo and pd.notna(row.get('close')):
                            pos = (row['close'] - lo) / max(hi - lo, 1e-8)
                            rsi_val = row.get('rsi')
                            e_lo   = float(settings.get('filters',{}).get('range_edge_low', 0.25))
                            e_hi   = float(settings.get('filters',{}).get('range_edge_high', 0.75))
                            r_long_max  = float(settings.get('filters',{}).get('range_rsi_long_max', 43))
                            r_short_min = float(settings.get('filters',{}).get('range_rsi_short_min', 57))
                            if side == 'long':
                                ok_micro = (pos <= e_lo) and pd.notna(rsi_val) and (rsi_val <= r_long_max)
                            else:
                                ok_micro = (pos >= e_hi) and pd.notna(rsi_val) and (rsi_val >= r_short_min)
                    else:
                        ok_micro = (row.get('micro_long', False) if side=='long' else row.get('micro_short', False))

                    # 하드 게이트 통과?
                    if ok_micro and _passes_entry_filters(row, settings, side):
                        # 레짐별 RR/SL/트레일 계수 적용
                        if row['regime'] == 'trend':
                            pm.rr = tuple(rconf.get('rr_trend', rconf.get('rr_base', [1, 2])))
                            pm.atr_sl_mult = float(rconf.get('atr_sl_mult_trend', 1.2))
                            pm.trail_conf['atr_trail_mult'] = float(tconf.get('atr_trail_mult_trend', 1.2))
                        else:
                            pm.rr = tuple(rconf.get('rr_range', rconf.get('rr_base', [1, 2])))
                            pm.atr_sl_mult = float(rconf.get('atr_sl_mult_range', 1.0))
                            pm.trail_conf['atr_trail_mult'] = float(tconf.get('atr_trail_mult_range', 0.8))

                        sess = which_session(now)
                        pm.open_position(side, price, atr, now,
                                         size=1.0,
                                         regime=row['regime'],
                                         strategy=type(strat).__name__,
                                         session=sess)
                        cool_left = cooldown

    # 4) 루프 종료 후 잔여 포지션 정리
    if not pm.flat():
        last = df.iloc[-1]
        now  = last['timestamp'].to_pydatetime()
        price= float(last['close'])
        rsi  = float(last['rsi'])
        atr  = float(last['atr'])

        pm.update_trailing(price, rsi, atr)
        partials = pm.try_maintenance(price, now)
        for p in partials:
            trades.append(p)

        soft = pm.maybe_soft_tp(price, now, rsi, last.get('macd_hist', 0.0), settings.get('soft_tp', {}))
        if soft:
            trades.append(soft)

        closed = pm.try_close(price, now, rsi, atr)
        if closed:
            trades.append(closed)

    # 리포트/로그
    headline = perf_headline(trades)
    by = breakdowns(trades)

    os.makedirs('logs', exist_ok=True)
    ts = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    with open(f'logs/last_report_{ts}.json','w',encoding='utf-8') as f:
        json.dump({'headline':headline, 'breakdowns':by}, f, ensure_ascii=False, indent=2)
    if len(trades) > 0:
        pd.DataFrame(trades).to_csv(f'logs/trades_{ts}.csv', index=False)

    report = dict(headline)
    report['details_saved'] = True
    return report

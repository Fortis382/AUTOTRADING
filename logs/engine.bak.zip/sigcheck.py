import yaml, pandas as pd, numpy as np
from btcusdt_algo.core.indicators import add_indicators
from btcusdt_algo.core.features import build_features
from btcusdt_algo.core.scoring import SignalScorer, adaptive_threshold
from btcusdt_algo.core.mtf import resample_with_indicators, merge_mtf
from btcusdt_algo.core.session import score_mult, which as which_session
from btcusdt_algo.strategies.ensemble import route_by_regime

cfg = yaml.safe_load(open("config/settings.yaml","r",encoding="utf-8"))
df = pd.read_parquet("data/processed/BTCUSDT_1m.parquet")
df = add_indicators(df, cfg)
d5  = resample_with_indicators(df, '5min', cfg, cols=('rsi','ema21'))
d15 = resample_with_indicators(df, '15min', cfg, cols=('rsi','ema21'))
df = merge_mtf(df, d5, '5m'); df = merge_mtf(df, d15, '15m')
df = build_features(df, use_detectors=True, cfg=cfg)

# 점수/임계
sc = SignalScorer(weights=cfg.get('scoring_weights', {'volatility':0.25,'momentum':0.25,'volume':0.20,'structure':0.20,'fib':0.10}),
                  squeeze_th=cfg['indicators'].get('bb_squeeze_th',0.02))
df['score_raw'] = df.apply(lambda r: sc.score_row(r, session_mult=1.0), axis=1)
thr = cfg['thresholding']; 
if thr.get('mode','fixed')=='adaptive':
    df['thr'] = adaptive_threshold(df['score_raw'], window_bars=int(thr.get('window_bars',4320)),
                                   pct=float(thr.get('adaptive_percentile',0.85)), floor=float(thr.get('floor',72)))
else:
    df['thr'] = float(thr.get('fixed_score_th',75.0))

# 마이크로 트리거
from btcusdt_algo.detectors.microtrigger import micro_triggers
micro = micro_triggers(df, lookback_break=int(cfg.get('micro',{}).get('break_lookback',10)),
                          rsi_on=float(cfg.get('micro',{}).get('rsi_on',57.0)))
df = pd.concat([df, micro], axis=1)

# 하드 게이트 체크 함수 (엔진 것과 동일 로직)
from btcusdt_algo.core.session import which as which_session
def passes(row, side):
    f = cfg.get('filters', {})
    # 세션 차단
    blocked = set(cfg.get('session',{}).get('block',[]) or [])
    if blocked:
        if which_session(row['timestamp'].to_pydatetime()) in blocked: 
            return False
    # MTF
    if f.get('require_mtf', True):
        rsi_min = float(f.get('mtf_rsi_min', 52.0))
        r5, r15 = row.get('rsi_5m'), row.get('rsi_15m')
        e5, e1  = row.get('ema21_5m'), row.get('ema21')
        if side=='long':
            if r5 is not None and r5 < rsi_min: return False
            if r15 is not None and r15 < rsi_min: return False
            if f.get('mtf_use_ema_gate', True) and (e5 is not None and row['close']<e5) and (e1 is not None and row['close']<e1): 
                return False
        else:
            if r5 is not None and r5 > 100-rsi_min: return False
            if r15 is not None and r15 > 100-rsi_min: return False
            if f.get('mtf_use_ema_gate', True) and (e5 is not None and row['close']>e5) and (e1 is not None and row['close']>e1): 
                return False
    # MACD hist sign
    if f.get('require_macd_hist_sign', True):
        mh = row.get('macd_hist', None)
        if mh is not None:
            if side=='long' and mh<0: return False
            if side=='short' and mh>0: return False
    return True

# 카운트
c_all   = len(df)
c_valid = df[['rsi','atr','bb_mid','bb_width']].dropna().shape[0]
c_score = int((df['score_raw'] >= df['thr']).sum())

# 전략 라우팅 + 마이크로 + 하드게이트
from btcusdt_algo.core.regime import classify_regime
reg = cfg.get('regime',{})
df['regime'] = classify_regime(df, reg.get('trend_adx_min',22), cfg['indicators'].get('bb_squeeze_th',0.028))
def ok_entry(row):
    strat = route_by_regime(row['regime'])
    side  = 'long' if strat.should_long(row) else ('short' if strat.should_short(row) else '')
    if not side: return False
    micro_ok = (row.get('micro_long',False) if side=='long' else row.get('micro_short',False))
    if not micro_ok: return False
    return passes(row, side)

c_gate  = int(df[(df['score_raw']>=df['thr'])].apply(ok_entry, axis=1).sum())

print(f"rows_all={c_all} | valid_indicators={c_valid}")
print(f"score>=thr bars = {c_score}")
print(f"score>=thr && micro && hard_gate bars = {c_gate}")
